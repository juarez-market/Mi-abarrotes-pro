# Mi Abarrotes Pro

Aplicación multiplataforma base para inventario y punto de venta.

## Incluye
- Inicio / dashboard
- Punto de venta
- Inventario con categorías, búsqueda, orden y alertas
- Caja
- Reportes
- Clientes/proveedores
- Respaldo JSON
- PWA instalable en Android, iPhone/iPad y computadora compatible

## Importante
Esta entrega es una versión funcional local/prototipo. Los datos se guardan en el dispositivo.
Para publicar en Google Play y App Store y sincronizar varios dispositivos, el siguiente paso es envolver la PWA con Capacitor y conectar una base de datos/autenticación en la nube.

## Prueba rápida
Abre `web/index.html` en un navegador moderno.
Para instalación PWA y algunas funciones móviles, sirve la carpeta mediante HTTPS o un servidor local.

## Estructura recomendada para producción
- Frontend: esta interfaz
- Empaquetado móvil/escritorio: Capacitor
- Backend: API segura
- Base de datos: PostgreSQL/Supabase/Firebase
- Autenticación: usuarios y roles
- Sincronización offline
- Escáner de código de barras
- Impresión térmica
